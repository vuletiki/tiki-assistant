chrome.browserAction.onClicked.addListener(function(tab) {
    window.open('https://tiki.vn?src=chr-ext-icon','_blank');
});